package com.capgemini.flightmanagement.dto;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;

public class UserLogin {
	
	HashMap<Integer,User> map=new HashMap<Integer,User>();
//  public  User user;
  User user1=new User("Admin",1,"kapil kumar","123","kapil@123",823333311);
  User user2=new User("user",2,"vipin kumar","123","vipin@123",823333311);
  User user3=new User("user",3,"rahul kumar","123","rahul@123",823333311);
  User user4=new User("user",4,"ritil raj","321","vipin@123",823333311);
  public User user;
  
 public void addUser() {
	 map.put(1, user1);
	 map.put(2, user2);
	 map.put(3, user3);
	 map.put(4, user4);
	 
	 
//File file=new File("C:\\Users\\kapil chaudhary\\Documents\\FlightManagementSystem1\\src\\main\\resources\\User.txt");
//  
//	 
//	 try {
//		 System.out.println("kapil");
//		
//	 FileOutputStream fout=new FileOutputStream(file);  
//	
//	 ObjectOutputStream out=new ObjectOutputStream(fout);
//	 
//	 
//	 out.writeObject(map);
//
//	 // out.flush();  
//	  out.close();  
//	  fout.close();
//	  System.out.println("success");  
//	 }catch(Exception e) {
//		 System.out.println(e);
//		 e.setStackTrace(null);
//	 }
	 
 }
 
 public boolean validate(String user,String pass) {
	 File file=new File("C:\\Users\\kapil chaudhary\\Documents\\FlightManagementSystem1\\src\\main\\resources\\User.txt");
	  
	  try {
		  FileInputStream fis=new FileInputStream(file);
		  ObjectInputStream oos=new ObjectInputStream(fis);
		  HashMap<Integer, User> map1 = (HashMap) oos.readObject();
		  		oos.close();
		  		
		  	  for(Map.Entry m : map1.entrySet())  
		      {  
		  		 User b= (User)m.getValue();
		  	
		  		
		  		if(b.getUserEmail().equals(user)) {
		    		 if(b.getUserPassword().equals(pass)) {	
		    			 return true;
		    		 }
		    		 }
		    	 }
		 
     
	 }catch(Exception e) {
		 System.out.println(e);
	 }
	 
	 return false;
 }
  
	

}
