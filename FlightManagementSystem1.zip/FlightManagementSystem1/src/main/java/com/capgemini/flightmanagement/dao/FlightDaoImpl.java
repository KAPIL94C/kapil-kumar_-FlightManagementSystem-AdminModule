package com.capgemini.flightmanagement.dao;

import java.util.Scanner;

import com.capgemini.flightmanagement.dto.Flight;
import com.capgemini.flightmanagement.service.FlightServiceImpl;

public class FlightDaoImpl {
	
	public void  adminWork() {
		Scanner sc=new Scanner(System.in);
		FlightServiceImpl   flightServiceObj=new FlightServiceImpl();
		Flight flight;
		System.out.println("\n\n*****************************************************************************");
		System.out.println("------------------------------WELCOME ADMIN!!!!----------------------------------");
        System.out.println("**********************************************************************************");
					System.out.println("Enter your choice:");
					System.out.println("1. Add Flight:");
					System.out.println("2. Schedule A Flight");
					System.out.println("3. Search A Flight");
					System.out.println("4. Search Scheduled Flight");
					System.out.println("5. View Flight Available");
					System.out.println("6. View Scheduled Flight");
					System.out.println("7. Delete Scheduled Flight");
					System.out.println("8. Logout");
				
					int n=sc.nextInt();
		
		
		switch(n){
		
		case 1:
					flight=new Flight();
					flightServiceObj.addFlight(flight);
					this.adminWork();
					break;
		case 2:
					System.out.println("Enter the Flight Id:");
					Integer flightId=sc.nextInt();
					flightServiceObj.scheduleFlight(flightId);
					this.adminWork();
			
					break;
					
		case 3:     System.out.println("Enter the Flight Number:");
		            Integer b=sc.nextInt();
						flightServiceObj.searchFlight(b);
						this.adminWork();
					break;
		case 4:
					break;
		case 5:
					flightServiceObj.viewFlight();
					this.adminWork();
					break;
		case 6:
					break;
		case 7:
					break;
		case 8:     
					break;
	    default :
	    			System.out.println("You Enter the Wrong choice:");
		}
		
	}

}

