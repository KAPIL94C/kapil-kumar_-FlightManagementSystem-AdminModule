package com.capgemini.flightmanagement.exe;

import java.util.Scanner;

import com.capgemini.flightmanagement.dao.FlightDaoImpl;
import com.capgemini.flightmanagement.dto.UserLogin;

public class MainClass {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		UserLogin us=new UserLogin();
		us.addUser();
		System.out.println("***********************************************************************************");
		System.out.println("--------------------------------WELCOME TO HOME PAGE-------------------------------");
		System.out.println("************************************************************************************");
		System.out.println("Enter your Choice :");
		System.out.println("1. User Login");
		System.out.println("2. Admin Login");
		System.out.println("3. view flight");
		int n=sc.nextInt();
		
		switch(n) {
		case 1: 
			break;
		case 2: System.out.println("Enter the userName:");
		      String user=sc.next();
		      System.out.println("Enter the password :");
		      String pass=sc.next();
			if(us.validate(user,pass)) {
				System.out.println("Valid User:");
				FlightDaoImpl  flightDao=new FlightDaoImpl();
				flightDao.adminWork();
				
			}else {
				System.out.println("Wrong UseName or Password:");
			}
			
			break;
		case 3:
			  
			break;
		default : System.out.println("Yout Enter the wrong choice ");
		}
	}

}
