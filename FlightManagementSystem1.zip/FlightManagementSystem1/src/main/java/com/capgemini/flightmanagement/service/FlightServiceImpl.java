package com.capgemini.flightmanagement.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.flightmanagement.dto.Airport;
import com.capgemini.flightmanagement.dto.Flight;
import com.capgemini.flightmanagement.dto.Schedule;
import com.capgemini.flightmanagement.dto.ScheduledFlight;
import com.capgemini.flightmanagement.dto.User;

public class FlightServiceImpl {
	Scanner  sc=new Scanner(System.in);
	Schedule schedule;

		
		ArrayList<HashMap<Integer, Flight>> al = new ArrayList<HashMap<Integer, Flight>>();
		HashMap<Integer, Flight> hm = new HashMap<Integer, Flight>();
		
		ArrayList<HashMap<Integer, Flight>> al2 = new ArrayList();
		HashMap<Integer, Flight> hm2 = new HashMap();
		
				ArrayList<Flight>  list=new ArrayList();
				ArrayList<Schedule>  scheduleList=new ArrayList();
				ArrayList<Airport>  airList=new ArrayList();
	
		public void  addAirport() {
						Airport a1=new Airport("abc","123","Delhi");
						Airport a2=new Airport("xyz","124","Mumbai");
						Airport a3=new Airport("pqr","125","Patna");
						Airport a4=new Airport("xml","126","Banglore");
						Airport a5=new Airport("tml","127","Gujrat");
						Airport a6=new Airport("pqr","125","Jammu");
						Airport a7=new Airport("xml","126","Lucknow");
						Airport a8=new Airport("tml","127","Agra");
	
							airList.add(a1);
							airList.add(a2);
							airList.add(a3);
							airList.add(a4);
							airList.add(a5);
							airList.add(a6);
							airList.add(a7);
							airList.add(a8);
							
//		File path = new File("C:\\Users\\kapil chaudhary\\Documents\\FlightManagementSystem1\\src\\main\\resources\\Airport.txt");
//		FileOutputStream fos = null;
//		try {
//			fos = new FileOutputStream(path);
//			ObjectOutputStream out = new ObjectOutputStream(fos);
//			out.writeObject(airList);
//	
//		} catch(Exception ex) {
//			ex.printStackTrace();
//		}
	
	}//fuction end
	
	
	public void addFlight(Flight flight){
		
		
		System.out.println("Enter the  flight no.");
		Integer no=sc.nextInt();
				
			
			  				flight.setFlightNumber(no);
			  				sc.nextLine();
	     
			  				System.out.println("Enter Flight Model");
			  				String m=sc.nextLine();
			  				flight.setFlightModel(m);
	
			  				System.out.println("Enter Flight Name");
			  				String n=sc.nextLine();
			  				flight.setCarrierName(n);

			  				System.out.println("Enter  seat capacity");
			  				Integer c=sc.nextInt();
			  				flight.setSeatCapacity(c);
			  			
			  			
//			  				ArrayList<HashMap<Integer, Flight>> al = new ArrayList<HashMap<Integer, Flight>>();
//			  				hm.put(flight.getFlightNumber(), flight);
//			  				al.add(0,hm);
 //        	  				this.m1(al);

                 this.m2(flight);
     
        
      	 
		
	}
	
	
	public static void m1(ArrayList<HashMap<Integer, Flight>> al) {
		File path = new File("C:\\Users\\kapil chaudhary\\Documents\\FlightManagementSystem1\\src\\main\\resources\\flight.txt");
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(path);
			ObjectOutputStream out = new ObjectOutputStream(fos);
			out.writeObject(al);
	
		} catch(Exception ex) {
			ex.printStackTrace();
		}	
	}
	
	public void m2(Flight flight) {
		System.out.println("in the m2 method");
		
		File path = new File("C:\\Users\\kapil chaudhary\\Documents\\FlightManagementSystem1\\src\\main\\resources\\flight.txt");
		FileInputStream fis = null;
		FileOutputStream fos = null;
		ArrayList<HashMap<Integer, Flight>> al = null;
		try {
			fis = new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fis);
			al = (ArrayList<HashMap<Integer, Flight>>)in.readObject();
			System.out.println(al);
			HashMap<Integer, Flight> hm = al.get(0);
			hm.put(flight.getFlightNumber(), flight);
			//hm.clear();
			al.set(0,hm);
			System.out.println(flight);
			in.close();
			fis.close();
			FileOutputStream fout=new FileOutputStream(path);  
		   	ObjectOutputStream out=new ObjectOutputStream(fout);
	   	    out.writeObject(al);
	   	    // out.flush();  
	   		   out.close();  
	   		   fout.close();
	   		   System.out.println("Flight Added Successfuly!!"); 
   	 		}catch(Exception e) {
   	 			System.out.println(e);
   	 			e.setStackTrace(null);
   	 		}
     
		
		
	}
	
	
	//-----------------------------------------------------------SCHEDULE FLIGHT-----------------------
public void scheduleFlight(Integer flightId) {

	
	Flight flight;
	Airport airport=null;
	Iterator<Flight> it=list.iterator();
	while(it.hasNext()) {
		if(it.next().getFlightNumber().equals(flightId)) {
			 flight=it.next();
			break;
		}else {
			System.out.println("Flight of id do not exists");
			return ;
		}
	}
	
	Schedule schedule=new Schedule();
	
	System.out.println("Enter the sourceAirport code");
	String source=sc.nextLine();
	
	Iterator<Airport> itAirport=airList.iterator();
	while(itAirport.hasNext()) {
		if(itAirport.next().getAirportCode().equals(source)) {
			airport=itAirport.next();
			break;
		}else {
			System.out.println("Source Airport is not available");
			return ;
		}
	}
	
	
	 schedule=new Schedule();
	 schedule.setSourceAirport(airport);
	 
	 

		System.out.println("Enter the destinationAirport code");
		String destination=sc.nextLine();
	 
	
	 while(itAirport.hasNext()) {
			if(itAirport.next().getAirportCode().equals(destination)) {
				airport=itAirport.next();
				break;
			}else {
				System.out.println("Destination Airport is not available");
				return ;
			}
		}

	 schedule=new Schedule();
	 schedule.setSourceAirport(airport);
	 
	 
	 SimpleDateFormat df = new SimpleDateFormat("mm/dd/yyyy");
	 
	 
	 try {
	        System.out.print("ENTER Arrival DATE STRING (mm/dd/yyyy ): ");
	        String dateString = sc.nextLine();
	        // Parse the date
	        Date date = df.parse(dateString);
	       schedule.setArrivalTime(date);
	       System.out.print("ENTER departure DATE STRING (mm/dd/yyyy ): ");
	        String dateString1 = sc.nextLine();
	        // Parse the date
	        Date date1 = df.parse(dateString1);
	       schedule.setArrivalTime(date);
	    }
	    catch(Exception e) {
      System.out.println("Enter the correct date");
	    }
	 scheduleList.add(schedule);
	 System.out.println("Scheduled succesfully");
	
	
	
}
//-----------------------------------------------------END SCHEDULE FLIGHT---------------------------------



public void searchFlight(Integer b) {
	
	
	 try{
		 		File path = new File("C:\\Users\\kapil chaudhary\\Documents\\FlightManagementSystem1\\src\\main\\resources\\flight.txt");
	 
		 		FileInputStream fis=new FileInputStream(path);
		 		ObjectInputStream in = new ObjectInputStream(fis);
		 		al = (ArrayList<HashMap<Integer, Flight>>)in.readObject();
		 		Iterator it=al.iterator();
		 		
		 		HashMap<Integer, Flight> hm= (HashMap<Integer, Flight>) it.next();
			
		 				for(Map.Entry m:hm.entrySet()){    
		 				
		 					if(m.getKey().equals(b)) {
		 					System.out.println(m.getValue());
		 					return;
		 					
		 					
		 					}
		 			}
			
		 		System.out.println("Flight do not exists:");
			
			
	
	 }catch(Exception e) {
		 					System.out.println(e);
	 
	 					}
}
public void searchScheduledFlight(Integer b) {
	
}
public void viewFlight() {
	
	 try {
		 File path = new File("C:\\Users\\kapil chaudhary\\Documents\\FlightManagementSystem1\\src\\main\\resources\\flight.txt");
	 
		  FileInputStream fis=new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fis);
			al = (ArrayList<HashMap<Integer, Flight>>)in.readObject();
	//----------------------------------------
		
		Iterator it=al.iterator();
 		
 		HashMap<Integer, Flight> hm= (HashMap<Integer, Flight>) it.next();
	
 				for(Map.Entry m:hm.entrySet()){    
 				
 				
 					System.out.println(" "+m.getValue());
 				
 					
 					
 					}
 			

		
		
		
		
		
			
	//---------------------------------------------------------		
	
	 }catch(Exception e) {
		 System.out.println(e);
	 }
	}
	

public void viewScheduledFlight() {
	
	
}
public void deleteFlight(Integer a){
	
}

public void validateFlight(Flight a) {
	
}




	
	
}


	
	

