package com.capgemini.flightmanagement.dto;

import java.util.Date;
import java.util.List;

public class Booking {

	private Integer bookingId;
	private  User userId;
	private Date bookingDate;
	private List<Passenger> PassengerList;
	private double ticketCost;
	private Flight flight;
	private Integer noOfPassengers;
	
	
	public Booking() {
	
	}
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}
	public User getUserId() {
		return userId;
	}
	public void setUserId(User userId) {
		this.userId = userId;
	}
	public Date getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}
	public List<Passenger> getPassengerList() {
		return PassengerList;
	}
	public void setPassengerList(List<Passenger> passengerList) {
		PassengerList = passengerList;
	}
	public double getTicketCost() {
		return ticketCost;
	}
	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	public Integer getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(Integer noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	
	
	
	

}
