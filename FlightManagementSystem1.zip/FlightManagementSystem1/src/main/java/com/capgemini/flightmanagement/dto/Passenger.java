package com.capgemini.flightmanagement.dto;

public class Passenger {
	
	private  Integer pnrNumber;
	private String passengerName;
	private Integer passengerAge;
	private Integer passengerUIN;
	private String  luggage;
	public Passenger() {
	
	}
	public Integer getPnrNumber() {
		return pnrNumber;
	}
	public void setPnrNumber(Integer pnrNumber) {
		this.pnrNumber = pnrNumber;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public Integer getPassengerAge() {
		return passengerAge;
	}
	public void setPassengerAge(Integer passengerAge) {
		this.passengerAge = passengerAge;
	}
	public Integer getPassengerUIN() {
		return passengerUIN;
	}
	public void setPassengerUIN(Integer passengerUIN) {
		this.passengerUIN = passengerUIN;
	}
	public String getLuggage() {
		return luggage;
	}
	public void setLuggage(String luggage) {
		this.luggage = luggage;
	}
	
	
	
	
	

}
