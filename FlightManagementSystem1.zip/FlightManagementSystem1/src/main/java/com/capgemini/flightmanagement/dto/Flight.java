package com.capgemini.flightmanagement.dto;

import java.io.Serializable;

public class Flight implements Serializable {
	
	
	private Integer flightNumber;
	private String flightModel;
	private String carrierName;
	private Integer seatCapacity;
	public Flight() {
		super();
	}
	public Integer getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(Integer flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getFlightModel() {
		return flightModel;
	}
	public void setFlightModel(String flightModel) {
		this.flightModel = flightModel;
	}
	public String getCarrierName() {
		return carrierName;
	}
	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}
	public Integer getSeatCapacity() {
		return seatCapacity;
	}
	public void setSeatCapacity(Integer seatCapacity) {
		this.seatCapacity = seatCapacity;
	}
	@Override
	public String toString() {
		return "[flightNumber = " + flightNumber + ", flightModel = " + flightModel + ", carrierName = " + carrierName
				+ ", seatCapacity = " + seatCapacity + "]";
	}
	
	

}
